// background.js (MV3 service worker)
// Handles messages from content.js: looks up an abstract, classifies it,
// caches the result, and returns it.
//
// Two reliability rules this file follows, because a service worker can be
// suspended by Chrome at any time (e.g. when its tab isn't focused):
//   1. Every network call has a timeout, so one stalled request can't leave
//      a badge stuck on "checking…" forever.
//   2. Per-tab counters live in chrome.storage.session, not a plain JS
//      variable, so they survive the worker being unloaded and restarted.

const CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const REVIEW_KEYWORDS = /\b(survey|review|systematic review|meta-analysis|overview of)\b/i;

const ABSTRACT_TIMEOUT_MS = 6000;
const LLM_TIMEOUT_MS = 12000;
const TEST_TIMEOUT_MS = 8000;
// Hard ceiling on the whole classifyPaper() pipeline (abstract lookup, then
// the model ensemble). Individual network calls already time out on their
// own, but nothing previously bounded the *combined* worst case — a slow
// abstract lookup stacked with a slow model call could together run long
// enough that Chrome tears down the message channel back to content.js
// before sendResponse() ever fires ("the message port closed before a
// response was received"), leaving that paper's badge stuck pending
// forever. This guarantees classifyPaper() always settles well before that,
// falling back to the keyword heuristic if the real pipeline is too slow.
const OVERALL_CLASSIFY_TIMEOUT_MS = 20000;

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    chrome.storage.session.remove(tabStatsKey(tabId)).catch(() => {});
    setBadge(tabId, '', null);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'CLASSIFY_PAPER') {
    classifyPaper(message.title)
      .then(async (result) => {
        if (sender.tab?.id != null) await recordStat(sender.tab.id, result);
        sendResponse(result);
      })
      .catch(() => sendResponse({ error: 'unavailable' }));
    return true; // keep the message channel open for the async sendResponse
  }

  if (message?.type === 'GET_TAB_STATUS') {
    getTabStats(message.tabId).then(sendResponse);
    return true;
  }

  if (message?.type === 'TEST_KEY') {
    testKey(message.provider, message.key, message.model)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, message: String(err) }));
    return true;
  }

  return false;
});

// --- Per-tab stats, persisted so a worker restart doesn't lose them -------

function tabStatsKey(tabId) {
  return `tabstats:${tabId}`;
}

async function getTabStats(tabId) {
  const stored = await chrome.storage.session.get(tabStatsKey(tabId));
  return stored[tabStatsKey(tabId)] || { research: 0, review: 0, total: 0 };
}

async function recordStat(tabId, result) {
  const stats = await getTabStats(tabId);
  if (result.type === 'Review') stats.review += 1;
  else if (result.type === 'Research') stats.research += 1;
  else return; // classification errored out — don't count it
  stats.total += 1;

  await chrome.storage.session.set({ [tabStatsKey(tabId)]: stats });
  setBadge(tabId, String(stats.total), '#06AED5');
}

// Classification can now take up to ~20s (see OVERALL_CLASSIFY_TIMEOUT_MS),
// which is plenty of time for the person to close the tab before a result
// comes back. chrome.action.setBadgeText/setBadgeBackgroundColor throw
// "No tab with id: <id>" in that case — an entirely expected race, not a
// real failure — so it's swallowed here instead of surfacing as an
// unhandled promise rejection in the service worker's console.
function setBadge(tabId, text, color) {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  if (color) chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}

// --- Networking helper -----------------------------------------------------

async function fetchWithTimeout(url, options = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// --- Classification pipeline ------------------------------------------------

async function classifyPaper(title) {
  const cacheKey = 'classify:' + normalize(title);
  const cached = await getCache(cacheKey);
  if (cached) return cached;

  const result = await withOverallTimeout(
    classifyUncached(title),
    OVERALL_CLASSIFY_TIMEOUT_MS,
    () => heuristicClassify(title)
  );

  await setCache(cacheKey, result);
  return result;
}

async function classifyUncached(title) {
  const abstract = await fetchAbstract(title);
  // If no abstract was found, still ask the AI — using just the title is
  // meaningfully better than a keyword regex — before falling back further.
  return abstract ? await classifyWithLLM(title, abstract) : await classifyTitleOnly(title);
}

// Races `promise` against a timer. Whichever settles first wins; the loser
// is simply ignored (its own timeouts/AbortControllers still clean it up
// independently). Used so classifyPaper() can never take meaningfully
// longer than `ms`, regardless of how slow the network calls inside it are.
function withOverallTimeout(promise, ms, fallbackFn) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve(fallbackFn());
    }, ms);

    promise.then(
      (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      },
      () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(fallbackFn());
      }
    );
  });
}

async function testKey(provider, key, model) {
  if (!key || !model) return { ok: false, message: 'Add both a key and a model first.' };

  const result = await callProviderChat(
    provider,
    key,
    model,
    'Reply with the single word: ok',
    TEST_TIMEOUT_MS
  );

  if (result.ok) return { ok: true, message: 'Connected.' };
  return { ok: false, message: result.message };
}

function normalize(text) {
  return text.trim().toLowerCase().replace(/\s+/g, ' ');
}

async function getCache(key) {
  const stored = await chrome.storage.local.get(key);
  const entry = stored[key];
  if (!entry || Date.now() - entry.savedAt > CACHE_TTL_MS) return null;
  // Entries saved by a pre-ensemble-reasoning version of this extension
  // won't have `reason`/`details` — treat them as a miss so the paper gets
  // reclassified once (and re-cached in the new shape) instead of silently
  // showing an empty "why" panel until the 30-day TTL clears it out.
  if (!('reason' in entry.value) || !('details' in entry.value)) return null;
  return entry.value;
}

async function setCache(key, value) {
  await chrome.storage.local.set({ [key]: { value, savedAt: Date.now() } });
}

// --- Abstract lookup ------------------------------------------------------

function titleSimilarity(a, b) {
  a = normalize(a);
  b = normalize(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  const shorter = a.length < b.length ? a : b;
  const longer = a.length < b.length ? b : a;
  if (longer.includes(shorter)) return shorter.length / longer.length;
  const aTokens = new Set(a.split(' '));
  const bTokens = new Set(b.split(' '));
  const overlap = [...aTokens].filter((t) => bTokens.has(t)).length;
  return overlap / Math.max(aTokens.size, bTokens.size);
}

// Semantic Scholar and OpenAlex are queried in parallel — previously this
// waited for Semantic Scholar to finish (or time out) before ever trying
// OpenAlex, which roughly doubled the wait on any paper Semantic Scholar
// doesn't have. Whichever answers first with a usable abstract wins.
async function fetchAbstract(title) {
  const [ss, oa] = await Promise.allSettled([
    fetchFromSemanticScholar(title),
    fetchFromOpenAlex(title),
  ]);
  if (ss.status === 'fulfilled' && ss.value) return ss.value;
  if (oa.status === 'fulfilled' && oa.value) return oa.value;
  return null;
}

async function fetchFromSemanticScholar(title) {
  const url =
    'https://api.semanticscholar.org/graph/v1/paper/search' +
    `?query=${encodeURIComponent(title)}&fields=title,abstract&limit=1`;
  const res = await fetchWithTimeout(url, {}, ABSTRACT_TIMEOUT_MS);
  if (!res.ok) return null;
  const data = await res.json();
  const paper = data?.data?.[0];
  if (!paper?.abstract) return null;
  if (titleSimilarity(title, paper.title) < 0.6) return null;
  return paper.abstract;
}

async function fetchFromOpenAlex(title) {
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(title)}&per-page=1`;
  const res = await fetchWithTimeout(url, {}, ABSTRACT_TIMEOUT_MS);
  if (!res.ok) return null;
  const data = await res.json();
  const work = data?.results?.[0];
  if (!work) return null;
  if (titleSimilarity(title, work.display_name) < 0.6) return null;
  // OpenAlex stores abstracts as a word -> positions map, not plain text.
  return reconstructAbstract(work.abstract_inverted_index);
}

function reconstructAbstract(invertedIndex) {
  if (!invertedIndex) return null;
  const positions = [];
  for (const [word, indices] of Object.entries(invertedIndex)) {
    for (const idx of indices) positions[idx] = word;
  }
  const text = positions.join(' ').trim();
  return text || null;
}

// --- Classification ---------------------------------------------------

// `callResult` is what callEnsembleClassifier() returned: null if zero
// models are configured at all, or { attempts } if models are configured
// but every one of them failed/timed out for this specific paper. The
// message and source differ between those two cases — conflating them
// used to make "all your models are failing" look identical to "you never
// configured any," which made real problems (bad model slug, rate limits,
// an OpenRouter outage) invisible.
function heuristicClassify(title, callResult) {
  const match = title.match(REVIEW_KEYWORDS);
  const isReview = Boolean(match);
  const titleReason = isReview
    ? `Title contains the review-type keyword "${match[0]}".`
    : 'Title does not contain any review-type keywords (survey, review, meta-analysis, etc.), so it defaults to Research.';

  if (callResult && Array.isArray(callResult.attempts) && callResult.attempts.length > 0) {
    const n = callResult.attempts.length;
    return {
      type: isReview ? 'Review' : 'Research',
      confidence: 55,
      source: 'title-heuristic-all-failed',
      reason: `All ${n} configured model${n > 1 ? 's' : ''} failed to respond for this paper (see attempts below), so this falls back to a keyword-only guess. ${titleReason}`,
      // Keep the failed attempts visible in the "why" panel instead of
      // silently dropping them — this is what makes a rate-limited or
      // misconfigured model visible instead of just quietly vanishing.
      details: callResult.attempts.map(attemptToDetail),
    };
  }

  return {
    type: isReview ? 'Review' : 'Research',
    confidence: 55,
    source: 'title-heuristic',
    reason: titleReason,
    details: [],
  };
}

async function classifyWithLLM(title, abstract) {
  const result = await callEnsembleClassifier(buildAbstractPrompt(title, abstract));
  if (result && result.successes.length > 0) {
    return { ...ensemble(result.successes, result.attempts), source: 'llm' };
  }
  return heuristicClassify(title, result);
}

// Used when no abstract could be found. A title-only guess from an actual
// model is still meaningfully better than a fixed keyword regex, and is
// labeled distinctly in the UI so it isn't confused with an abstract-verified
// result.
async function classifyTitleOnly(title) {
  const result = await callEnsembleClassifier(buildTitleOnlyPrompt(title));
  if (result && result.successes.length > 0) {
    return { ...ensemble(result.successes, result.attempts), source: 'llm-title-only' };
  }
  return heuristicClassify(title, result);
}


function buildAbstractPrompt(title, abstract) {
  return `You are an expert at identifying academic paper types.
Classify the paper as exactly one of: "Research Paper" or "Review Paper".

Title: ${title}
Abstract: ${abstract}

Respond with ONLY compact JSON, no other text:
{"prediction":"Research" or "Review","research_probability":0-1,"review_probability":0-1,"reason":"one short sentence explaining why, based on the abstract"}`;
}

function buildTitleOnlyPrompt(title) {
  return `You are an expert at identifying academic paper types.
No abstract is available for this paper. Using only the title and your general knowledge of how research papers versus review papers are typically titled in this field, make your best judgment. Reflect your reduced certainty in the probabilities.

Title: ${title}

Classify as exactly one of: "Research Paper" or "Review Paper".
Respond with ONLY compact JSON, no other text:
{"prediction":"Research" or "Review","research_probability":0-1,"review_probability":0-1,"reason":"one short sentence explaining why, based on the title"}`;
}

// --- Multi-model ensemble ---------------------------------------------------
//
// Up to 5 OpenRouter (key, model) pairs can be configured. The exact same
// prompt is sent to every "always" pair in parallel via Promise.allSettled
// so that a failure or timeout on one model never blocks the others. Pairs
// marked "only use if needed" are held back and only called if none of the
// "always" pairs came back usable. Each model is expected to return
// {prediction, research_probability, review_probability}; the probabilities
// from every model that answered successfully are averaged to produce the
// final result.

// Reads the configured (key, model, onlyIfNeeded) tuples from storage.
// Supports the new `openrouterConfigs` array (up to 5 entries) and falls
// back to the legacy single `openrouterKey` / `openrouterModel` fields so
// existing installs keep working without any migration step.
async function getConfiguredPairs() {
  const stored = await chrome.storage.local.get([
    'openrouterConfigs',
    'openrouterKey',
    'openrouterModel',
  ]);

  let configs = Array.isArray(stored.openrouterConfigs) ? stored.openrouterConfigs : [];
  configs = configs
    .filter((c) => c && typeof c.key === 'string' && typeof c.model === 'string')
    .map((c) => ({
      // Rows saved before multi-provider support has no `provider` field at
      // all — those were always OpenRouter, so default to that rather than
      // silently dropping the row or misrouting the key.
      provider: PROVIDER_CALLERS[c.provider] ? c.provider : 'openrouter',
      key: c.key.trim(),
      model: c.model.trim(),
      onlyIfNeeded: Boolean(c.onlyIfNeeded),
    }))
    .filter((c) => c.key && c.model)
    .slice(0, 5);

  if (configs.length === 0 && stored.openrouterKey && stored.openrouterModel) {
    configs = [{ provider: 'openrouter', key: stored.openrouterKey, model: stored.openrouterModel, onlyIfNeeded: false }];
  }

  return configs;
}

// Shared OpenRouter call used by both classification paths above.
// Returns:
//   - null                          if zero models are configured at all
//   - { successes, attempts }       if models are configured — `successes`
//                                    is what actually produced a usable
//                                    prediction (may be empty), `attempts`
//                                    is every pair that was tried, success
//                                    or not, so a failure is never just
//                                    silently dropped on the floor.
//
// Each configured pair can be marked "only use if needed" on the settings
// page. Those are held back and only called if every regular ("always")
// pair failed/timed out/errored — so a cheap or rate-limited backup key
// isn't spending a request on every single paper, only on the ones the
// primary model(s) couldn't handle.
async function callEnsembleClassifier(prompt) {
  const pairs = await getConfiguredPairs();
  if (pairs.length === 0) return null;

  const always = pairs.filter((p) => !p.onlyIfNeeded);
  const fallback = pairs.filter((p) => p.onlyIfNeeded);

  let attempts = await runPairs(always, prompt);
  let successes = attempts.filter((a) => a.ok);

  if (successes.length === 0 && fallback.length > 0) {
    const fallbackAttempts = await runPairs(fallback, prompt);
    attempts = attempts.concat(fallbackAttempts);
    successes = fallbackAttempts.filter((a) => a.ok);
  }

  return { successes, attempts };
}

// Runs a group of (key, model) pairs in parallel via Promise.allSettled and
// returns an attempt record for every single one — never just the ones
// that worked. This is what makes a rate-limited or misconfigured model
// visible in the "why" panel instead of silently vanishing, which
// previously made "3 models configured, 1 responding" look identical to
// "only 1 model was ever configured."
async function runPairs(pairs, prompt) {
  if (pairs.length === 0) return [];

  const settled = await Promise.allSettled(
    pairs.map((pair) => callSingleModel(pair.provider, pair.key, pair.model, prompt))
  );

  return settled.map((s, i) => {
    if (s.status === 'fulfilled') return s.value;
    // callSingleModel is written to never reject in practice, but if some
    // unexpected exception did slip through, still surface it as a
    // recognizable failed attempt rather than losing the model entirely.
    return { model: pairs[i].model, ok: false, message: String(s.reason?.message || s.reason || 'Unknown error') };
  });
}

// --- Per-provider chat callers ----------------------------------------
//
// Each configured row can independently be OpenRouter, Google Gemini, or
// xAI Grok — three different request/response shapes hitting three
// different hosts. Each function below always resolves (never rejects)
// with either { ok: true, text } or { ok: false, message }, so
// callSingleModel() can treat all three identically afterward.

async function callOpenRouterChat(key, model, prompt, timeoutMs) {
  try {
    const res = await fetchWithTimeout(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0,
        }),
      },
      timeoutMs
    );

    if (!res.ok) {
      const body = await res.json().catch(() => null);
      const detail = body?.error?.message || `HTTP ${res.status}`;
      // OpenRouter/most providers return 429 for rate limiting — the classic
      // cause of ":free" models (capped ~20 req/min) failing partway through
      // a results page while other configured models keep succeeding.
      const message = res.status === 429 ? `Rate limited (${detail})` : detail;
      return { ok: false, message };
    }

    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content || '';
    return { ok: true, text };
  } catch (err) {
    return { ok: false, message: err?.name === 'AbortError' ? 'Timed out.' : 'Network error.' };
  }
}

// xAI's Grok API is OpenAI-compatible, so the request/response shape is
// identical to OpenRouter's — only the host and (implicitly) the model
// catalog differ.
async function callGrokChat(key, model, prompt, timeoutMs) {
  try {
    const res = await fetchWithTimeout(
      'https://api.x.ai/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0,
        }),
      },
      timeoutMs
    );

    if (!res.ok) {
      const body = await res.json().catch(() => null);
      const detail = body?.error?.message || `HTTP ${res.status}`;
      const message = res.status === 429 ? `Rate limited (${detail})` : detail;
      return { ok: false, message };
    }

    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content || '';
    return { ok: true, text };
  } catch (err) {
    return { ok: false, message: err?.name === 'AbortError' ? 'Timed out.' : 'Network error.' };
  }
}

// Google's Generative Language API (Gemini). Auth is a `key` query param
// rather than a header, and the request/response envelope (`contents` /
// `candidates`) is shaped differently from the OpenAI-style chat APIs
// above, so this can't share their request builder.
async function callGeminiChat(key, model, prompt, timeoutMs) {
  try {
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent` +
      `?key=${encodeURIComponent(key)}`;
    const res = await fetchWithTimeout(
      url,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0 },
        }),
      },
      timeoutMs
    );

    if (!res.ok) {
      const body = await res.json().catch(() => null);
      const detail = body?.error?.message || `HTTP ${res.status}`;
      const message = res.status === 429 ? `Rate limited (${detail})` : detail;
      return { ok: false, message };
    }

    const data = await res.json();
    const candidate = data?.candidates?.[0];
    const text = (candidate?.content?.parts || []).map((p) => p.text || '').join('');
    // Gemini can stop for safety filters or other reasons without ever
    // producing text, which would otherwise look like a generic "response
    // wasn't in the expected format" parse failure instead of the real cause.
    if (!text && candidate?.finishReason && candidate.finishReason !== 'STOP') {
      return { ok: false, message: `Gemini stopped early (${candidate.finishReason}).` };
    }
    return { ok: true, text };
  } catch (err) {
    return { ok: false, message: err?.name === 'AbortError' ? 'Timed out.' : 'Network error.' };
  }
}

const PROVIDER_CALLERS = {
  openrouter: callOpenRouterChat,
  grok: callGrokChat,
  gemini: callGeminiChat,
};

function callProviderChat(provider, key, model, prompt, timeoutMs) {
  const caller = PROVIDER_CALLERS[provider] || PROVIDER_CALLERS.openrouter;
  return caller(key, model, prompt, timeoutMs);
}

// Calls a single (provider, key, model) trio with the given prompt and
// parses its response. Always resolves (never rejects) with an attempt
// record — { model, ok: true, ...prediction } on success, or
// { model, ok: false, message } describing exactly why it failed
// (timed out, bad HTTP status, unparseable output) — so the caller always
// has something concrete to show the user instead of just "it didn't work."
async function callSingleModel(provider, key, model, prompt) {
  const result = await callProviderChat(provider, key, model, prompt, LLM_TIMEOUT_MS);
  if (!result.ok) return { model, ok: false, message: result.message };

  const parsed = parseModelOutput(result.text);
  if (!parsed) return { model, ok: false, message: "Response wasn't in the expected format." };
  return { model, ok: true, ...parsed };
}

// Converts one attempt record (success or failure) into the shape the
// "why" panel renders. Kept separate from ensemble() so heuristicClassify()
// can reuse it too when every model failed.
function attemptToDetail(a) {
  if (a.ok) {
    return {
      model: a.model,
      prediction: a.prediction,
      research_probability: a.research_probability,
      review_probability: a.review_probability,
      reason: a.reason || '',
    };
  }
  return { model: a.model, failed: true, message: a.message || 'Failed to respond.' };
}

// Averages the probabilities from every model that answered successfully
// and derives the final prediction/confidence from that average. On top of
// the { type, confidence } shape the rest of the extension already expects,
// this now also returns:
//   - reason:  a one-line summary of how the models agreed/disagreed
//   - details: every attempted model — successes with their prediction, and
//              failures with why they failed — so the UI can show "why" on
//              demand without changing what's displayed by default, and
//              without hiding a model that was attempted but failed.
function ensemble(successes, attempts) {
  const avgResearch = successes.reduce((sum, r) => sum + r.research_probability, 0) / successes.length;
  const avgReview = successes.reduce((sum, r) => sum + r.review_probability, 0) / successes.length;

  const type = avgResearch >= avgReview ? 'Research' : 'Review';
  const confidence = Math.round(Math.max(avgResearch, avgReview) * 100);

  const agreeing = successes.filter((r) => r.prediction === type).length;
  const failedCount = attempts.length - successes.length;
  let reason;
  if (successes.length === 1 && failedCount === 0) {
    reason = successes[0].reason || `Classified as ${type}.`;
  } else if (failedCount > 0) {
    reason = `${agreeing} of ${successes.length} responding model${successes.length > 1 ? 's' : ''} classified this as ${type} (${failedCount} of ${attempts.length} configured model${attempts.length > 1 ? 's' : ''} failed to respond — see below), averaging ${confidence}% confidence.`;
  } else {
    reason = `${agreeing} of ${successes.length} models classified this as ${type}, averaging ${confidence}% confidence.`;
  }

  return { type, confidence, reason, details: attempts.map(attemptToDetail) };
}

function parseModelOutput(text) {
  try {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return null;
    const parsed = JSON.parse(match[0]);

    let researchProb = Number(parsed.research_probability);
    let reviewProb = Number(parsed.review_probability);
    if (!Number.isFinite(researchProb) || !Number.isFinite(reviewProb)) return null;

    // Normalize in case a model's pair doesn't sum to exactly 1.
    const sum = researchProb + reviewProb;
    if (sum <= 0) return null;
    researchProb /= sum;
    reviewProb /= sum;

    const prediction = /review/i.test(String(parsed.prediction)) ? 'Review' : 'Research';
    const reason = typeof parsed.reason === 'string' ? parsed.reason.trim().slice(0, 300) : '';
    return { prediction, research_probability: researchProb, review_probability: reviewProb, reason };
  } catch {
    return null;
  }
}

// =============================================================================
// Highlight -> Find Citation (added in v6)
//
// Fully additive: nothing above this line was modified. This section adds
// one new message type ('FIND_CITATIONS'), handled by its own
// chrome.runtime.onMessage.addListener() call rather than adding a branch to
// the existing listener above, so the original listener and every message
// type it handles are untouched.
//
// Deliberately spends ZERO LLM tokens/calls — this whole feature runs
// without touching getConfiguredPairs()/callProviderChat() at all, so it
// costs nothing beyond the free search APIs below, regardless of how many
// (or how expensive) model rows are configured for classification. If you
// ever want AI-boosted relevance ranking here later, that's a separate,
// opt-in addition — not something this version does by default.
//
// Pipeline for one highlighted passage:
//   1. Check cache (30 days, same TTL as classification).
//   2. Extract a handful of search keywords locally (stopword-stripped,
//      longest/most-distinctive words first) — no model call.
//   3. Search Crossref + Semantic Scholar + OpenAlex in parallel (all free,
//      no API key required), merge, and de-dupe by title similarity
//      (reusing titleSimilarity()).
//   4. Score each candidate's relevance locally: what fraction of the
//      passage's keywords actually appear in that candidate's title/
//      abstract. Anything below a minimum overlap is dropped — the same
//      "don't show a weak, misleading match" goal as before, just computed
//      with plain word-overlap instead of an LLM judgment call.
//   5. Format the surviving candidates into APA/MLA/IEEE/BibTeX strings
//      (plain templates, not citeproc-js — see note below) and return
//      everything to the content script for display/insertion.
// =============================================================================

const CITE_CACHE_TTL_MS = CACHE_TTL_MS; // reuse the same 30-day window
const CITE_SEARCH_TIMEOUT_MS = 8000;
const CITE_OVERALL_TIMEOUT_MS = 20000;
const CITE_LOCAL_RELEVANCE_THRESHOLD = 20; // 0-100; % of passage keywords that must appear in a candidate
const CITE_MAX_RESULTS = 5;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'FIND_CITATIONS') {
    findCitations(message.text)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: 'unavailable' }));
    return true; // keep the message channel open for the async sendResponse
  }
  return false;
});

// --- Cache -------------------------------------------------------------
// Deliberately separate from getCache()/setCache() above: those validate
// that a cached value has classification-specific fields (`reason`,
// `details`), which citation results don't have — reusing them as-is would
// make every citation lookup look like a permanent cache miss. Same TTL
// approach, own key prefix, no shared state with the classification cache.

async function getCiteCache(key) {
  const stored = await chrome.storage.local.get(key);
  const entry = stored[key];
  if (!entry || Date.now() - entry.savedAt > CITE_CACHE_TTL_MS) return null;
  return entry.value;
}

async function setCiteCache(key, value) {
  await chrome.storage.local.set({ [key]: { value, savedAt: Date.now() } });
}

// Small non-cryptographic hash (djb2) so a long highlighted paragraph
// doesn't itself become the storage key — this is a local cache, not a
// security boundary, so collisions being astronomically unlikely is enough.
function citeHash(text) {
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = (hash * 33) ^ text.charCodeAt(i);
  }
  return (hash >>> 0).toString(36);
}

// --- Entry point ---------------------------------------------------------

async function findCitations(rawText) {
  const text = (rawText || '').trim();
  if (!text) return { ok: false, error: 'empty' };

  // A person can highlight a whole paragraph or more; bound the search size
  // rather than rejecting long selections outright.
  const claimText = text.length > 800 ? text.slice(0, 800) : text;

  const cacheKey = 'cite:' + citeHash(normalize(claimText));
  const cached = await getCiteCache(cacheKey);
  if (cached) return cached;

  const result = await withOverallTimeout(
    findCitationsUncached(claimText),
    CITE_OVERALL_TIMEOUT_MS,
    () => ({ ok: false, error: 'timeout' })
  );

  if (result.ok) await setCiteCache(cacheKey, result);
  return result;
}

async function findCitationsUncached(claimText) {
  const keywords = naiveKeywords(claimText);
  const candidates = await searchCandidates(keywords);
  if (candidates.length === 0) return { ok: false, error: 'no-results' };

  const scored = candidates.map((c) => {
    const { score, matched } = localRelevance(claimText, c);
    return {
      ...c,
      relevance: score,
      why: matched.length ? `Shares keywords: ${matched.slice(0, 5).join(', ')}` : '',
    };
  });

  const ranked = scored
    .filter((c) => c.relevance >= CITE_LOCAL_RELEVANCE_THRESHOLD)
    .sort((a, b) => b.relevance - a.relevance)
    .slice(0, CITE_MAX_RESULTS);

  if (ranked.length === 0) {
    // Candidates came back, but none shared enough vocabulary with the
    // passage to be worth suggesting as a citation for it.
    return { ok: false, error: 'no-strong-match' };
  }

  return {
    ok: true,
    source: 'keyword-match',
    keywords,
    results: ranked.map((c, i) => toResultShape(c, i + 1)),
  };
}

// --- Local keyword extraction & relevance scoring (no model calls) ----------

const CITE_STOPWORDS = new Set(
  'a an the of in on at to for and or but with from by is are was were has have had this that these those it its as be been being which who whom whose we our you your they their he she his her not no can may might will would should could than then so such also into over under about'.split(
    ' '
  )
);

function naiveKeywords(text) {
  const words = normalize(text)
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 2 && !CITE_STOPWORDS.has(w));
  // Longest, most distinctive-looking words first — a crude proxy for
  // "important" without a model to judge actual relevance.
  const uniq = [...new Set(words)].sort((a, b) => b.length - a.length);
  return uniq.slice(0, 6);
}

// Fraction of the passage's own keywords (not the narrower search-query
// keywords above — every keyword-length-4+ word in the passage) that show
// up in a candidate's title + abstract. Simple, free, and transparent: the
// "why" shown to the person is literally the words that matched, not an
// LLM's paraphrase of its own reasoning.
function localRelevance(claimText, candidate) {
  const claimWords = new Set(
    normalize(claimText)
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 3 && !CITE_STOPWORDS.has(w))
  );
  if (claimWords.size === 0) return { score: 0, matched: [] };

  const candidateWords = new Set(
    normalize(`${candidate.title} ${candidate.abstract || ''}`)
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
  );

  const matched = [...claimWords].filter((w) => candidateWords.has(w));
  const score = Math.round((matched.length / claimWords.size) * 100);
  return { score, matched };
}

// --- Candidate search (Crossref + Semantic Scholar + OpenAlex, in parallel) --
// All three are free and require no API key. Crossref is included per its
// strong DOI/metadata coverage, especially outside CS/AI (Semantic
// Scholar's specialty) — the three together cover more ground than any one
// alone, at no cost.

async function searchCandidates(keywords) {
  const query = keywords.join(' ');
  const [cr, ss, oa] = await Promise.allSettled([
    searchCrossref(query),
    searchSemanticScholar(query),
    searchOpenAlex(query),
  ]);
  const list = [];
  if (cr.status === 'fulfilled') list.push(...cr.value);
  if (ss.status === 'fulfilled') list.push(...ss.value);
  if (oa.status === 'fulfilled') list.push(...oa.value);
  return dedupeCandidates(list);
}

async function searchCrossref(query) {
  const url = `https://api.crossref.org/works?query=${encodeURIComponent(query)}&rows=8`;
  const res = await fetchWithTimeout(url, {}, CITE_SEARCH_TIMEOUT_MS);
  if (!res.ok) return [];
  const data = await res.json();
  return (data?.message?.items || [])
    .filter((it) => Array.isArray(it.title) && it.title[0])
    .map((it) => ({
      title: it.title[0],
      // Crossref abstracts (when present at all) come as JATS-tagged XML.
      abstract: (it.abstract || '').replace(/<[^>]+>/g, ''),
      authors: (it.author || [])
        .map((a) => [a.given, a.family].filter(Boolean).join(' '))
        .filter(Boolean),
      year:
        it['published-print']?.['date-parts']?.[0]?.[0] ||
        it['published-online']?.['date-parts']?.[0]?.[0] ||
        it.issued?.['date-parts']?.[0]?.[0] ||
        null,
      venue: (it['container-title'] || [])[0] || '',
      doi: it.DOI || '',
      url: it.URL || (it.DOI ? `https://doi.org/${it.DOI}` : ''),
    }));
}

async function searchSemanticScholar(query) {
  const url =
    'https://api.semanticscholar.org/graph/v1/paper/search' +
    `?query=${encodeURIComponent(query)}&fields=title,abstract,authors,year,venue,externalIds,url&limit=8`;
  const res = await fetchWithTimeout(url, {}, CITE_SEARCH_TIMEOUT_MS);
  if (!res.ok) return [];
  const data = await res.json();
  return (data?.data || [])
    .filter((p) => p.title)
    .map((p) => ({
      title: p.title,
      abstract: p.abstract || '',
      authors: (p.authors || []).map((a) => a.name).filter(Boolean),
      year: p.year || null,
      venue: p.venue || '',
      doi: p.externalIds?.DOI || '',
      url: p.url || (p.externalIds?.DOI ? `https://doi.org/${p.externalIds.DOI}` : ''),
    }));
}

async function searchOpenAlex(query) {
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(query)}&per-page=8`;
  const res = await fetchWithTimeout(url, {}, CITE_SEARCH_TIMEOUT_MS);
  if (!res.ok) return [];
  const data = await res.json();
  return (data?.results || [])
    .filter((w) => w.display_name)
    .map((w) => ({
      title: w.display_name,
      abstract: reconstructAbstract(w.abstract_inverted_index) || '',
      authors: (w.authorships || []).map((a) => a.author?.display_name).filter(Boolean),
      year: w.publication_year || null,
      venue: w.host_venue?.display_name || w.primary_location?.source?.display_name || '',
      doi: (w.doi || '').replace('https://doi.org/', ''),
      url: w.doi || w.id || '',
    }));
}

// Merges results from all three sources, folding near-duplicate titles
// together (reusing the same titleSimilarity() heuristic the abstract-
// lookup path already relies on) and keeping whichever copy has an
// abstract if only one of the duplicates does — an abstract is what makes
// localRelevance() above meaningful instead of title-only.
function dedupeCandidates(list) {
  const out = [];
  for (const item of list) {
    const dup = out.find((o) => titleSimilarity(o.title, item.title) > 0.85);
    if (!dup) out.push(item);
    else if (!dup.abstract && item.abstract) Object.assign(dup, item);
  }
  return out;
}

// --- Citation formatting -----------------------------------------------------
// Deliberately simple templates, not a full CSL processor — same
// honesty-over-completeness approach the existing BibTeX export already
// takes (see collections.js): no fabricated fields, clearly-approximate
// name splitting rather than a real bibliographic parser.

function splitName(full) {
  const parts = full.trim().split(/\s+/);
  if (parts.length === 1) return { last: parts[0], initials: '' };
  const last = parts[parts.length - 1];
  const initials = parts
    .slice(0, -1)
    .map((p) => (p[0] ? p[0].toUpperCase() + '.' : ''))
    .join(' ');
  return { last, initials };
}

function formatAuthorsAPA(authors) {
  if (!authors.length) return '';
  const formatted = authors.map((a) => {
    const { last, initials } = splitName(a);
    return initials ? `${last}, ${initials}` : last;
  });
  if (formatted.length === 1) return formatted[0];
  if (formatted.length === 2) return `${formatted[0]}, & ${formatted[1]}`;
  return `${formatted.slice(0, -1).join(', ')}, & ${formatted[formatted.length - 1]}`;
}

function formatAPA(c) {
  const authors = formatAuthorsAPA(c.authors);
  const year = c.year ? `(${c.year}).` : '(n.d.).';
  const venue = c.venue ? ` ${c.venue}.` : '';
  const lead = authors ? `${authors} ` : '';
  return `${lead}${year} ${c.title}.${venue}`.replace(/\s+/g, ' ').trim();
}

function formatMLA(c) {
  let authorPart = '';
  if (c.authors.length) {
    const { last, initials } = splitName(c.authors[0]);
    const firstName = initials ? initials.replace(/\./g, '') : '';
    authorPart = c.authors.length > 1 ? `${last}, ${firstName}, et al. ` : `${last}, ${firstName}. `;
  }
  const venue = c.venue ? ` ${c.venue},` : '';
  const year = c.year ? ` ${c.year}.` : '';
  return `${authorPart}"${c.title}."${venue}${year}`.replace(/\s+/g, ' ').trim();
}

function formatIEEE(c, index) {
  let authorPart = '';
  if (c.authors.length) {
    const { last, initials } = splitName(c.authors[0]);
    authorPart = c.authors.length > 1 ? `${initials} ${last} et al., ` : `${initials} ${last}, `;
  }
  const venue = c.venue ? ` ${c.venue},` : '';
  const year = c.year ? ` ${c.year}.` : '';
  return `[${index}] ${authorPart}"${c.title},"${venue}${year}`.replace(/\s+/g, ' ').trim();
}

function bibtexKey(c) {
  const lastName = c.authors[0] ? splitName(c.authors[0]).last.replace(/[^a-zA-Z]/g, '') : 'anon';
  const firstWord = (c.title || 'untitled').split(/\s+/)[0].replace(/[^a-zA-Z0-9]/g, '');
  return `${lastName}${c.year || ''}${firstWord}`;
}

function formatBibTeX(c) {
  const authors = c.authors.length ? c.authors.join(' and ') : 'Unknown';
  const lines = [`@article{${bibtexKey(c)},`, `  author = {${authors}},`, `  title = {${c.title}},`];
  if (c.venue) lines.push(`  journal = {${c.venue}},`);
  if (c.year) lines.push(`  year = {${c.year}},`);
  if (c.doi) lines.push(`  doi = {${c.doi}},`);
  if (c.url) lines.push(`  url = {${c.url}},`);
  lines.push('}');
  return lines.join('\n');
}

// Shapes one merged/ranked candidate into what the content script renders:
// display fields plus all four pre-formatted citation strings, so switching
// format in the popover never needs another message round-trip.
function toResultShape(c, ieeeIndex) {
  return {
    title: c.title,
    authors: c.authors || [],
    year: c.year || null,
    venue: c.venue || '',
    doi: c.doi || '',
    url: c.url || '',
    relevance: Number.isFinite(c.relevance) ? c.relevance : null,
    why: c.why || '',
    citations: {
      apa: formatAPA(c),
      mla: formatMLA(c),
      ieee: formatIEEE(c, ieeeIndex),
      bibtex: formatBibTeX(c),
    },
  };
}

// cite.js (added in v6)
// "Highlight -> Find Citation": highlight any passage on any page (or in a
// Google Doc), click the floating "Cite" button that appears, and get a
// short list of candidate papers with ready-to-use APA/MLA/IEEE/BibTeX
// citations. Clicking a result inserts it at the cursor.
//
// Fully additive and self-contained: this file doesn't touch, call, or
// depend on anything in content.js / collections.js / collections-content.js
// (those only run on scholar.google.com; this runs everywhere, including
// scholar.google.com, but shares no state with them). All heavy lifting
// (search, keyword extraction, re-ranking, formatting) happens in
// background.js via the 'FIND_CITATIONS' message; this file is UI only.
//
// Two selection-capture strategies, because Google Docs doesn't expose a
// normal DOM selection:
//   - Regular pages: window.getSelection() gives real text and a Range we
//     can restore later to insert at the same spot.
//   - Google Docs: the visible page is canvas-rendered, so getSelection()
//     doesn't reflect what's actually highlighted. Instead this triggers a
//     native copy (document.execCommand('copy')) and reads the clipboard
//     back — the same trick used to insert (see insertIntoDocs below). This
//     does mean using Cite in a Doc will overwrite your OS clipboard with
//     the highlighted text; the Cite button's tooltip says so.

const CITE_MIN_CHARS = 12;
const CITE_MAX_CHARS = 1000;
const CITE_IS_DOCS = location.hostname === 'docs.google.com';
const CITE_STYLE_STORAGE_KEY = 'citeDefaultStyle';

let citeBtn = null;
let citePopover = null;
let citeSavedRange = null; // regular pages: Range to restore before inserting
let citeSavedText = '';
let citeLastMouse = { x: 0, y: 0 }; // fallback anchor for Docs, where Range math doesn't apply

document.addEventListener('mousemove', (e) => {
  citeLastMouse = { x: e.clientX, y: e.clientY };
});

// --- Selection detection -----------------------------------------------------

function citeRemoveButton() {
  if (citeBtn) {
    citeBtn.remove();
    citeBtn = null;
  }
}

function citeClosePopover() {
  if (citePopover) {
    citePopover.remove();
    citePopover = null;
  }
}

function citeCloseAll() {
  citeRemoveButton();
  citeClosePopover();
}

function citeHandleSelectionChange() {
  // Never clobber an open popover just because the mouse moved over it, or
  // because clicking inside it collapsed the underlying page selection.
  if (citePopover) return;

  if (CITE_IS_DOCS) {
    // No usable getSelection() text on Docs — just show the button near
    // the cursor whenever the mouse is released after a drag; the actual
    // text is only read once the button is clicked (see onCiteClick).
    return;
  }

  const sel = window.getSelection();
  const text = sel && !sel.isCollapsed ? sel.toString().trim() : '';

  if (!text || text.length < CITE_MIN_CHARS || text.length > CITE_MAX_CHARS) {
    citeRemoveButton();
    return;
  }

  citeSavedRange = sel.getRangeAt(0).cloneRange();
  citeSavedText = text;
  const rect = citeSavedRange.getBoundingClientRect();
  citeShowButton(rect.right, rect.bottom);
}

document.addEventListener('mouseup', (e) => {
  // Let the click finish (so getSelection() reflects the final drag) before
  // reacting, and skip entirely if the mouseup was on our own UI.
  if (citeBtn?.contains(e.target) || citePopover?.contains(e.target)) return;
  setTimeout(() => {
    if (CITE_IS_DOCS) {
      // Docs: no real selection API, so just offer the button near the
      // cursor after any drag-release; whether there's actually something
      // worth citing is discovered when the button is clicked.
      citeShowButton(e.clientX, e.clientY + 16);
    } else {
      citeHandleSelectionChange();
    }
  }, 0);
});

// Keyboard-based selection (Shift+Arrow, Ctrl+A, etc.) on regular pages.
document.addEventListener('keyup', (e) => {
  if (CITE_IS_DOCS) return;
  if (citeBtn?.contains(document.activeElement) || citePopover) return;
  if (!['Shift', 'Control', 'Meta', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) return;
  citeHandleSelectionChange();
});

document.addEventListener('click', (e) => {
  if (citeBtn?.contains(e.target) || citePopover?.contains(e.target)) return;
  citeCloseAll();
});

// --- Floating "Cite" button --------------------------------------------------

function citeShowButton(x, y) {
  citeRemoveButton();

  citeBtn = document.createElement('button');
  citeBtn.type = 'button';
  citeBtn.className = 'lens81-cite-btn';
  citeBtn.textContent = '📎 Cite';
  citeBtn.title = CITE_IS_DOCS
    ? 'Find a citation for your selection. This briefly copies your selection to find its text, so it will replace what\u2019s currently on your clipboard.'
    : 'Find a citation for your selection';

  // Keep the current text selection alive — a plain click on any element
  // (including our own button) can otherwise collapse it via the browser's
  // default mousedown behavior before our click handler ever runs.
  citeBtn.addEventListener('mousedown', (e) => e.preventDefault());
  citeBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    onCiteClick();
  });

  const margin = 8;
  const left = Math.min(Math.max(x, margin), window.innerWidth - 90);
  const top = Math.min(Math.max(y, margin), window.innerHeight - 40);
  citeBtn.style.left = `${left + window.scrollX}px`;
  citeBtn.style.top = `${top + window.scrollY}px`;

  document.body.appendChild(citeBtn);
}

// --- Getting the highlighted text --------------------------------------------

async function citeGetSelectedText() {
  if (!CITE_IS_DOCS) return citeSavedText;

  // Google Docs: read back the current selection via a native copy. This
  // only works because clipboardRead/clipboardWrite are declared in
  // manifest.json — content scripts without those permissions can't do
  // this on a normal web page.
  try {
    const ok = document.execCommand('copy');
    if (!ok) return '';
    // Give the copy a brief tick to land before reading it back.
    await new Promise((r) => setTimeout(r, 60));
    const text = await navigator.clipboard.readText();
    return text.trim();
  } catch {
    return '';
  }
}

// --- Popover ------------------------------------------------------------------

async function onCiteClick() {
  const anchor = citeBtn;
  const rect = anchor.getBoundingClientRect();
  citeRemoveButton();
  citeShowPopoverLoading(rect);

  const text = await citeGetSelectedText();
  if (!text || text.length < CITE_MIN_CHARS) {
    citeShowPopoverMessage(
      CITE_IS_DOCS
        ? "Couldn't read your selection. Select some text in the document and try again."
        : "Couldn't find a text selection. Highlight a sentence or two and try again."
    );
    return;
  }

  chrome.runtime.sendMessage({ type: 'FIND_CITATIONS', text }, (response) => {
    if (chrome.runtime.lastError || !response) {
      citeShowPopoverMessage('Something went wrong reaching the extension. Try again.');
      return;
    }
    if (!response.ok) {
      citeShowPopoverMessage(citeErrorMessage(response.error));
      return;
    }
    citeRenderResults(response);
  });
}

function citeErrorMessage(error) {
  switch (error) {
    case 'no-results':
      return 'No candidate papers were found for this passage.';
    case 'no-strong-match':
      return "Found candidate papers, but none matched closely enough to suggest as a citation for this passage.";
    case 'timeout':
      return 'This took too long and timed out. Try again.';
    default:
      return "Couldn't find a citation for this passage right now.";
  }
}

function citePopoverShell() {
  citeClosePopover();
  const pop = document.createElement('div');
  pop.className = 'lens81-cite-pop';
  pop.addEventListener('click', (e) => e.stopPropagation());
  pop.addEventListener('mousedown', (e) => e.stopPropagation());
  document.body.appendChild(pop);
  citePopover = pop;
  return pop;
}

function citePositionPopover(pop, rect) {
  const margin = 8;
  const width = 340;
  let left = rect.left + window.scrollX;
  let top = rect.bottom + window.scrollY + 6;
  if (left + width > window.innerWidth + window.scrollX - margin) {
    left = window.innerWidth + window.scrollX - width - margin;
  }
  left = Math.max(left, margin + window.scrollX);
  pop.style.left = `${left}px`;
  pop.style.top = `${top}px`;
}

function citeShowPopoverLoading(rect) {
  const pop = citePopoverShell();
  citePositionPopover(pop, rect);
  pop.innerHTML = '';
  const loading = document.createElement('div');
  loading.className = 'lens81-cite-loading';
  loading.textContent = 'Searching for citations…';
  pop.appendChild(loading);
}

function citeShowPopoverMessage(message) {
  if (!citePopover) return;
  citePopover.innerHTML = '';
  const note = document.createElement('div');
  note.className = 'lens81-cite-message';
  note.textContent = message;
  citePopover.appendChild(note);

  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'lens81-cite-close';
  closeBtn.textContent = 'Close';
  closeBtn.addEventListener('click', citeCloseAll);
  citePopover.appendChild(closeBtn);
}

async function citeGetDefaultStyle() {
  const stored = await chrome.storage.local.get(CITE_STYLE_STORAGE_KEY);
  return stored[CITE_STYLE_STORAGE_KEY] || 'apa';
}

function citeSetDefaultStyle(style) {
  chrome.storage.local.set({ [CITE_STYLE_STORAGE_KEY]: style });
}

function citeSourceNote(source) {
  // Only one source exists now that this feature never calls an LLM
  // ('keyword-match') — kept as a function (rather than removed outright)
  // so a future source label can add a note here without touching the
  // render call site below.
  return '';
}

async function citeRenderResults(response) {
  if (!citePopover) return;
  const pop = citePopover;
  pop.innerHTML = '';
  pop.classList.add('lens81-cite-pop-wide');

  const heading = document.createElement('div');
  heading.className = 'lens81-cite-pop-title';
  heading.textContent = 'Citations found';
  pop.appendChild(heading);

  const note = citeSourceNote(response.source);
  if (note) {
    const noteEl = document.createElement('div');
    noteEl.className = 'lens81-cite-note';
    noteEl.textContent = note;
    pop.appendChild(noteEl);
  }

  const defaultStyle = await citeGetDefaultStyle();
  const list = document.createElement('div');
  list.className = 'lens81-cite-list';

  response.results.forEach((r) => {
    list.appendChild(citeBuildResultRow(r, defaultStyle));
  });
  pop.appendChild(list);

  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'lens81-cite-close';
  closeBtn.textContent = 'Close';
  closeBtn.addEventListener('click', citeCloseAll);
  pop.appendChild(closeBtn);
}

function citeAuthorsLine(authors) {
  if (!authors.length) return 'Unknown authors';
  if (authors.length <= 2) return authors.join(', ');
  return `${authors[0]} et al.`;
}

function citeBuildResultRow(result, defaultStyle) {
  const row = document.createElement('div');
  row.className = 'lens81-cite-row';

  const title = document.createElement('div');
  title.className = 'lens81-cite-row-title';
  title.textContent = result.title;
  row.appendChild(title);

  const meta = document.createElement('div');
  meta.className = 'lens81-cite-row-meta';
  const bits = [citeAuthorsLine(result.authors)];
  if (result.year) bits.push(String(result.year));
  if (result.venue) bits.push(result.venue);
  meta.textContent = bits.join(' · ');
  row.appendChild(meta);

  if (Number.isFinite(result.relevance)) {
    const rel = document.createElement('div');
    rel.className = 'lens81-cite-row-relevance';
    rel.textContent = `${result.relevance}% match${result.why ? ' — ' + result.why : ''}`;
    row.appendChild(rel);
  }

  const controls = document.createElement('div');
  controls.className = 'lens81-cite-row-controls';

  const select = document.createElement('select');
  select.className = 'lens81-cite-style-select';
  [
    ['apa', 'APA'],
    ['mla', 'MLA'],
    ['ieee', 'IEEE'],
    ['bibtex', 'BibTeX'],
  ].forEach(([value, label]) => {
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    if (value === defaultStyle) opt.selected = true;
    select.appendChild(opt);
  });
  controls.appendChild(select);

  const insertBtn = document.createElement('button');
  insertBtn.type = 'button';
  insertBtn.className = 'lens81-cite-insert-btn';
  insertBtn.textContent = 'Insert';
  controls.appendChild(insertBtn);

  const copyBtn = document.createElement('button');
  copyBtn.type = 'button';
  copyBtn.className = 'lens81-cite-copy-btn';
  copyBtn.title = 'Copy citation text';
  copyBtn.textContent = '📋';
  controls.appendChild(copyBtn);

  const status = document.createElement('span');
  status.className = 'lens81-cite-row-status';
  controls.appendChild(status);

  select.addEventListener('change', () => citeSetDefaultStyle(select.value));

  insertBtn.addEventListener('click', async () => {
    const text = result.citations[select.value];
    const ok = await citeInsertText(text);
    status.textContent = ok ? 'Inserted' : 'Copied — paste with Ctrl/Cmd+V';
    setTimeout(() => {
      status.textContent = '';
    }, 2500);
  });

  copyBtn.addEventListener('click', async () => {
    const text = result.citations[select.value];
    try {
      await navigator.clipboard.writeText(text);
      status.textContent = 'Copied';
    } catch {
      status.textContent = 'Copy failed';
    }
    setTimeout(() => {
      status.textContent = '';
    }, 2000);
  });

  row.appendChild(controls);
  return row;
}

// --- Insertion ----------------------------------------------------------------
// Always writes the citation to the clipboard first, regardless of platform
// or whether the programmatic insert appears to succeed — since success
// can't be verified with full confidence on either path, this guarantees a
// manual Ctrl/Cmd+V always works as a fallback.

async function citeInsertText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    // Clipboard write failing isn't fatal — the programmatic insert below
    // may still work; only the "paste manually" fallback is lost.
  }

  if (CITE_IS_DOCS) return citeInsertIntoDocs(text);
  return citeInsertIntoPage(text);
}

function citeFocusDocsEditor() {
  const iframe = document.querySelector('.docs-texteventtarget-iframe');
  const target = iframe?.contentDocument?.activeElement || iframe?.contentDocument?.body;
  if (target && typeof target.focus === 'function') target.focus();
}

async function citeInsertIntoDocs(text) {
  try {
    citeFocusDocsEditor();
    // execCommand('paste') is blocked for ordinary web pages, but content
    // scripts with the clipboardRead/clipboardWrite permissions declared in
    // manifest.json are allowed to use it — this is what actually lets the
    // citation land at the cursor instead of only sitting on the clipboard.
    return document.execCommand('paste');
  } catch {
    return false;
  }
}

function citeInsertIntoPage(text) {
  const active = document.activeElement;

  // Textarea/input: manipulate value directly — execCommand('insertText')
  // is unreliable across browsers for these elements.
  if (active && /^(TEXTAREA|INPUT)$/.test(active.tagName)) {
    try {
      const el = active;
      const start = el.selectionStart ?? el.value.length;
      const end = el.selectionEnd ?? el.value.length;
      el.value = el.value.slice(0, start) + text + el.value.slice(end);
      el.selectionStart = el.selectionEnd = start + text.length;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    } catch {
      return false;
    }
  }

  // contenteditable regions: restore the selection we saved when the
  // button first appeared (clicking into the popover moved focus away from
  // it), then use the standard insertText command.
  if (citeSavedRange) {
    try {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(citeSavedRange);
      if (document.execCommand('insertText', false, text)) return true;
    } catch {
      // fall through to "just copied" below
    }
  }

  // Not an editable spot at all (e.g. highlighting text on an article
  // you're reading, not writing) — clipboard write above is the real
  // result here; report that plainly instead of claiming an insert.
  return false;
}

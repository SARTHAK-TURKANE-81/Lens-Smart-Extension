const setupCta = document.getElementById('setup-cta');
const statsEl = document.getElementById('stats');
const idleNote = document.getElementById('idle-note');
const researchCountEl = document.getElementById('research-count');
const reviewCountEl = document.getElementById('review-count');
const statsNote = document.getElementById('stats-note');

function setState({ showSetup, showStats, showIdle }) {
  setupCta.classList.toggle('show', showSetup);
  statsEl.classList.toggle('show', showStats);
  idleNote.style.display = showIdle ? 'block' : 'none';
}

async function init() {
  const { openrouterKey, openrouterModel } = await chrome.storage.local.get([
    'openrouterKey',
    'openrouterModel',
  ]);
  const configured = Boolean(openrouterKey && openrouterModel);

  if (!configured) {
    setState({ showSetup: true, showStats: false, showIdle: false });
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const onScholar = Boolean(tab?.url && tab.url.includes('scholar.google.com'));

  if (!onScholar || tab.id == null) {
    setState({ showSetup: false, showStats: false, showIdle: true });
    return;
  }

  chrome.runtime.sendMessage({ type: 'GET_TAB_STATUS', tabId: tab.id }, (stats) => {
    if (chrome.runtime.lastError || !stats) {
      setState({ showSetup: false, showStats: false, showIdle: true });
      return;
    }
    researchCountEl.textContent = String(stats.research || 0);
    reviewCountEl.textContent = String(stats.review || 0);
    statsNote.textContent =
      stats.total > 0 ? 'Classified so far on this tab.' : 'Waiting for results to load on this tab…';
    setState({ showSetup: false, showStats: true, showIdle: false });
  });
}

document.getElementById('open-settings-cta').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById('gear').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

init();

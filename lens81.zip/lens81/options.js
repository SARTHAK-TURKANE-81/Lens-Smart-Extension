const keyInput = document.getElementById('key');
const modelInput = document.getElementById('model');
const toggleKeyBtn = document.getElementById('toggle-key');
const saveBtn = document.getElementById('save');
const testBtn = document.getElementById('test');
const status = document.getElementById('status');
const banner = document.getElementById('banner');
const clearStatus = document.getElementById('clear-status');

let statusGeneration = 0;

function showStatus(kind, message) {
  // kind: 'ok' | 'err' | 'neutral'
  statusGeneration++;
  status.textContent = message;
  status.className = `pill-status ${kind}`;
  status.style.display = 'inline-flex';
}

function hideStatusLater(delay = 2200) {
  // Capture the generation so a stale timer (e.g. from Save) can't hide a
  // newer message shown afterward (e.g. from Test connection).
  const generation = statusGeneration;
  setTimeout(() => {
    if (generation === statusGeneration) {
      status.style.display = 'none';
    }
  }, delay);
}

async function refreshBanner() {
  const { openrouterKey, openrouterModel } = await chrome.storage.local.get([
    'openrouterKey',
    'openrouterModel',
  ]);
  banner.classList.toggle('show', !(openrouterKey && openrouterModel));
}

async function load() {
  const { openrouterKey, openrouterModel } = await chrome.storage.local.get([
    'openrouterKey',
    'openrouterModel',
  ]);
  if (openrouterKey) keyInput.value = openrouterKey;
  if (openrouterModel) modelInput.value = openrouterModel;
  await refreshBanner();
}

toggleKeyBtn.addEventListener('click', () => {
  const hidden = keyInput.type === 'password';
  keyInput.type = hidden ? 'text' : 'password';
  toggleKeyBtn.textContent = hidden ? 'Hide' : 'Show';
});

saveBtn.addEventListener('click', async () => {
  const openrouterKey = keyInput.value.trim();
  const openrouterModel = modelInput.value.trim();
  await chrome.storage.local.set({ openrouterKey, openrouterModel });
  showStatus('ok', 'Saved.');
  hideStatusLater();
  await refreshBanner();
});

testBtn.addEventListener('click', async () => {
  const key = keyInput.value.trim();
  const model = modelInput.value.trim();

  if (!key || !model) {
    showStatus('err', 'Add a key and model first.');
    return;
  }

  showStatus('neutral', 'Testing…');
  testBtn.disabled = true;

  chrome.runtime.sendMessage({ type: 'TEST_KEY', key, model }, (response) => {
    testBtn.disabled = false;
    if (chrome.runtime.lastError || !response) {
      showStatus('err', 'Could not reach the background worker.');
      return;
    }
    showStatus(response.ok ? 'ok' : 'err', response.message);
    if (!response.ok) return; // leave the error visible until the user acts
    hideStatusLater(3000);
  });
});

document.getElementById('clear-cache').addEventListener('click', async () => {
  const all = await chrome.storage.local.get(null);
  const cacheKeys = Object.keys(all).filter((k) => k.startsWith('classify:'));
  await chrome.storage.local.remove(cacheKeys);
  clearStatus.textContent = `Cleared ${cacheKeys.length} cached result(s).`;
  setTimeout(() => (clearStatus.textContent = ''), 2500);
});

document.getElementById('back').addEventListener('click', () => {
  // Options pages usually open in their own tab with nothing before them in
  // history, so fall back to closing the tab when there's nowhere to go back to.
  if (window.history.length > 1) {
    window.history.back();
  } else {
    window.close();
  }
});

load();
